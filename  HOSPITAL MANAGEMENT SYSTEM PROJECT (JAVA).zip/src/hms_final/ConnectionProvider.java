/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms_final;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author aaaastark
 */
public class ConnectionProvider {
//    String myDatabase;
    public static Connection getCon()
    {
        
        String myDatabase = "CREATE DATABASE IF NOT EXISTS hmsjavaproject";
        String testTable= "CREATE TABLE IF NOT EXISTS testTable("
                + "testID varchar(20) not null, "
                + "testName varchar(100) not null, "
                + "primary key (testID))";
        String labTable= "CREATE TABLE IF NOT EXISTS labtable("
                + "labID varchar(20) not null, "
                + "labName varchar(100) not null, "
                + "primary key (labID))";
        String labPatientTable = "CREATE TABLE IF NOT EXISTS labpatienttable("
                + "patientID varchar(20) not null, "
                + "labID varchar(20) not null, "
                + "testID varchar(20) not null, "
                + "sampleName varchar(100) not null, "
                + "primary key (patientID,labID,testID))";
        String wardStaffTable= "CREATE TABLE IF NOT EXISTS wardstafftable("
                + "staffID varchar(20) not null, "
                + "staffName varchar(100) not null, "
                + "primary key (staffID))";
        String wardTable = "CREATE TABLE IF NOT EXISTS wardtable("
                + "wardID varchar(20) not null, "
                + "wardName varchar(100) not null, "
                + "wardLocation varchar(100) not null, "
                + "wardDepartment varchar(100) not null, "
                + "primary key (wardID))";
        String wardPatientReceptionTable= "CREATE TABLE IF NOT EXISTS wardpatientreceptiontable("
                + "wardID varchar(20) not null, "
                + "patientID varchar(20) not null, "
                + "receptionID varchar(20) not null, "
                + "primary key (wardID))";
        String wardAllocateTable= "CREATE TABLE IF NOT EXISTS wardallocatetable("
                 + "wardID varchar(20) not null, "
                 + "primary key (wardID))";
        String wardDeAllocateTable= "CREATE TABLE IF NOT EXISTS warddeallocatetable("
                 + "wardID varchar(20) not null, "
                 + "primary key (wardID))";
        String wardAvailableTable= "CREATE TABLE IF NOT EXISTS wardavailabletable("
                 + "wardID varchar(20) not null, "
                 + "primary key (wardID))";
        String wardNotAvailableTable= "CREATE TABLE IF NOT EXISTS wardnotavailabletable("
                 + "wardID varchar(20) not null, "
                 + "primary key (wardID))";
        String receptionTable = "CREATE TABLE IF NOT EXISTS receptiontable("
                + "receptionID varchar(20) not null, "
                + "receptionCounter varchar(100) not null, "
                + "receptionDepartment varchar(100) not null, "
                + "primary key (receptionID))";
        String cashManagementTable= "CREATE TABLE IF NOT EXISTS cashmanagementtable("
                + "patientID varchar(20) not null, "
                + "wardID varchar(20) not null, "
                + "assignAmount varchar(100) not null, "
                + "primary key (patientID))";
        String pharmacistTable= "CREATE TABLE IF NOT EXISTS pharmacisttable("
                + "pharmacistID varchar(20) not null, "
                + "pharmacistName varchar(100) not null, "
                + "primary key (pharmacistID))";
        String billMedicinesTable= "CREATE TABLE IF NOT EXISTS billmedicinestable("
                + "patientID varchar(20) not null, "
                + "medicinesName varchar(300) not null, "
                + "medicinesBill varchar(25) not null, "
                + "primary key (patientID))";
        String patientTable= "CREATE TABLE IF NOT EXISTS patientTable("
                + "patientID varchar(20) not null, "
                + "patientName varchar(100) not null, "
                + "patientGender varchar(25) not null, "
                + "patientAge varchar(10) not null, "
                + "patientPhone varchar(100) not null, "
                + "patientEmail varchar(100) not null, "
                + "patientAddress varchar(300) not null, "
                + "primary key (patientID))";
        String patientBillTable= "CREATE TABLE IF NOT EXISTS patientbillTable("
                + "patientID varchar(20) not null, "
                + "doctorID varchar(20) not null, "
                + "operationID varchar(20) not null, "
                + "testID varchar(20) not null, "
                + "doctorFee varchar(20) not null, "
                + "operationFee varchar(20) not null, "
                + "testFee varchar(20) not null, "
                + "rmiCharges varchar(20) not null, "
                + "billTotal varchar(30) not null,"
                + "primary key (patientID))";
        String operationTable= "CREATE TABLE IF NOT EXISTS operationTable("
                + "operationID varchar(20) not null, "
                + "operationName varchar(100) not null, "
                + "operationDate varchar(20) not null, "
                + "operationTime varchar(20) not null, "
                + "operationGenderType varchar(20) not null, "
                + "primary key (operationID))";
        String operationdetailsTable= "CREATE TABLE IF NOT EXISTS operationdetailsTable("
                + "doctorID varchar(20) not null, "
                + "patientID varchar(20) not null, "
                + "operationID varchar(20) not null, "
                + "primary key (operationID))";
        String doctorTable= "CREATE TABLE IF NOT EXISTS doctorTable("
                + "doctorID varchar(20) not null, "
                + "doctorName varchar(100) not null, "
                + "doctorRank varchar(20) not null, "
                + "doctorSpecialty varchar(100) not null, "
                + "doctorQualification varchar(100) not null, "
                + "primary key (doctorID))";
        String operationPerformTable= "CREATE TABLE IF NOT EXISTS operationperformTable("
                + "patientID varchar(20) not null, "
                + "doctorID varchar(20) not null, "
                + "operationID varchar(20) not null, "
                + "operationPerform varchar(20) not null, "
                + "primary key (patientID))";
        String madecinesAllowTable= "CREATE TABLE IF NOT EXISTS madecinesallowTable("
                + "patientID varchar(20) not null, "
                + "doctorID varchar(20) not null, "
                + "operationID varchar(20) not null, "
                + "medecinesAllow varchar(20) not null, "
                + "primary key (patientID))";
        String testsRequireTable= "CREATE TABLE IF NOT EXISTS testsrequireTable("
                + "patientID varchar(20) not null, "
                + "doctorID varchar(20) not null, "
                + "operationID varchar(20) not null, "
                + "testsRequire varchar(20) not null, "
                + "primary key (patientID))";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            
//                              XAMPP SERVER 
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
            Statement st = con.createStatement();
            st.executeUpdate(myDatabase);
            con.close();
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hmsjavaproject","root","");
            Statement st1 = con1.createStatement();
            st1.executeUpdate(testTable);
            st1.executeUpdate(labTable);
            st1.executeUpdate(labPatientTable);
            st1.executeUpdate(wardStaffTable);
            st1.executeUpdate(wardTable);
            st1.executeUpdate(wardPatientReceptionTable);
            st1.executeUpdate(wardAllocateTable);
            st1.executeUpdate(wardDeAllocateTable);
            st1.executeUpdate(wardAvailableTable);
            st1.executeUpdate(wardNotAvailableTable);
            st1.executeUpdate(receptionTable);
            st1.executeUpdate(cashManagementTable);
            st1.executeUpdate(pharmacistTable);
            st1.executeUpdate(billMedicinesTable);
            st1.executeUpdate(patientTable);
            st1.executeUpdate(patientBillTable);
            st1.executeUpdate(operationTable);
            st1.executeUpdate(operationdetailsTable);
            st1.executeUpdate(doctorTable);
            st1.executeUpdate(operationPerformTable);
            st1.executeUpdate(madecinesAllowTable);
            st1.executeUpdate(testsRequireTable);
            return con1;
                   
//                          Onlie MYSQL Panel Access Database
//            Connection con = DriverManager.getConnection("jdbc:mysql://sql11.freesqldatabase.com:3306/sql11455348","sql11455348","BwFwAHbX33");
//            Statement st1 = con.createStatement();
//            st1.executeUpdate(testTable);
//            st1.executeUpdate(labTable);
//            st1.executeUpdate(labPatientTable);
//            st1.executeUpdate(wardStaffTable);
//            st1.executeUpdate(wardTable);
//            st1.executeUpdate(wardPatientReceptionTable);
//            st1.executeUpdate(wardAllocateTable);
//            st1.executeUpdate(wardDeAllocateTable);
//            st1.executeUpdate(wardAvailableTable);
//            st1.executeUpdate(wardNotAvailableTable);
//            st1.executeUpdate(receptionTable);
//            st1.executeUpdate(cashManagementTable);
//            st1.executeUpdate(pharmacistTable);
//            st1.executeUpdate(billMedicinesTable);
//            st1.executeUpdate(patientTable);
//            st1.executeUpdate(patientBillTable);
//            st1.executeUpdate(operationTable);
//            st1.executeUpdate(operationdetailsTable);
//            st1.executeUpdate(doctorTable);
//            st1.executeUpdate(operationPerformTable);
//            st1.executeUpdate(madecinesAllowTable);
//            st1.executeUpdate(testsRequireTable);
//            JOptionPane.showMessageDialog(null,"The Database Connection.");
//            return con;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"The Database Connection Error. \n"+e);
            return null;
        }
    }
      
//    public static void main(String[] argv){
//        Connection con = getCon();
//        JOptionPane.showMessageDialog(null,"The Database Connection.\n"+con);
//    }
}
